﻿using System.Windows;
using Lab2IPZ.entity;

namespace Lab2IPZ;

public partial class NotificationDetails : Window
{
    private NotificationEntity _notificationEntity { get; set; }
    
    public NotificationDetails(NotificationEntity notificationEntity)
    {
        InitializeComponent();
        _notificationEntity = notificationEntity;
        DataContext = _notificationEntity;
        
        Console.WriteLine(_notificationEntity.Title);
    }

    private void Back_To_List_Click(object sender, RoutedEventArgs e)
    {
        // Повернення до списку сповіщень
        this.Close();
    }
}