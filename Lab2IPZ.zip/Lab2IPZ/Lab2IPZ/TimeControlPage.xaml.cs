﻿using System.Windows;
using System.Windows.Threading;
using Lab2IPZ.entity;
using Lab2IPZ.req;
using Lab2IPZ.resp;

namespace Lab2IPZ;

public partial class TimeControlPage : Window
{
    public TimeControlPage()
    {
        InitializeComponent();
        DataContext = new TimeControlViewModel();
    }
    
    private void Logout_Button_Click(object sender, RoutedEventArgs e)
    {
        var loginPage = new LoginPage();
        loginPage.Show();
        Close();
    }

    private void View_Menu(object sender, RoutedEventArgs e)
    {
        ScheduleSelectionWindow selectionWindow = new ScheduleSelectionWindow();
        
        if (selectionWindow.ShowDialog() == true)
        {
            string selectedOption = selectionWindow.SelectedOption;
            MessageBox.Show($"Ви вибрали: {selectedOption}");
            Close();
        }
    }
}