﻿using System.Windows;

namespace Lab2IPZ
{
    public partial class ScheduleSelectionWindow : Window
    {
        public string SelectedOption { get; private set; }

        public ScheduleSelectionWindow()
        {
            InitializeComponent();
        }

        private void S_Button_Click(object sender, RoutedEventArgs e)
        {
            SelectedOption = "Сповіщення";
            this.DialogResult = true;
            this.Close();
            
            var notificationPage = new NotificationPage();
            notificationPage.Show();
        }
        
        private void G_Button_Click(object sender, RoutedEventArgs e)
        {
            SelectedOption = "Графіки";
            this.DialogResult = true;
            this.Close();
            
            var schedulePage = new SchedulePage();
            schedulePage.Show();
        }
        
        private void R_Button_Click(object sender, RoutedEventArgs e)
        {
            SelectedOption = "Рейтинг успішних людей";
            this.DialogResult = true;
            this.Close();
            
            var ratingSuccessfulPeople = new RatingSuccessfullPeoplePage();
            ratingSuccessfulPeople.Show();
        }
    }
}