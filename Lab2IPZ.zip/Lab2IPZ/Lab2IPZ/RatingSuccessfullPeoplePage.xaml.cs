﻿using System.Collections.ObjectModel;
using System.Windows;
using Lab2IPZ.entity;
using Lab2IPZ.resp;

namespace Lab2IPZ;

public partial class RatingSuccessfullPeoplePage : Window
{
    public ObservableCollection<RatingSuccessfulEntity> RatingSuccessful { get; set; } =
        new ObservableCollection<RatingSuccessfulEntity>();
    public RatingSuccessfullPeoplePage()
    {
        InitializeComponent();
        LoadNotifications();
        DataContext = this;
    }
    
    private async void LoadNotifications()
    {
        try
        {
            var ratingSuccessful = await new RatingGetResponse().getRatingSuccessfulEntity();

            foreach (var rating in ratingSuccessful)
            {
                RatingSuccessful.Add(rating);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show($"Сталась помилка {e.Message}");
        }
    }

    private void Open_Time_Control_Page(object sender, RoutedEventArgs e)
    {
        var timeContolPage = new TimeControlPage();
        timeContolPage.Show();
        Close();
    }
}