﻿using System;
using System.Windows;
using Lab2IPZ.entity;
using Lab2IPZ.req;

namespace Lab2IPZ
{
    public partial class AddNotificationPage : Window
    {
        public NotificationEntity Notification { get; set; }

        public AddNotificationPage()
        {
            InitializeComponent();
            Notification = new NotificationEntity();
            DataContext = Notification;
        }   

        private void OnAddButtonClick(object sender, RoutedEventArgs e)
        {
            try {
                new NotificationCreateRequest(Notification.Title, Notification.Description).Add_Notification();
                               
                var notificationPage = new NotificationPage();
                notificationPage.Show();
                Close();
            }catch (Exception ex) {
                MessageBox.Show($"Сталась помилка {ex.Message}");
                throw;
            }
        }
        
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var notificationPage = new NotificationPage();
            notificationPage.Show();
            Close();
        }
    }
}