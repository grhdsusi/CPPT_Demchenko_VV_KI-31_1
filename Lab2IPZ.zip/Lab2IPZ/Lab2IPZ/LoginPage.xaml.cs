﻿
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using Lab2IPZ.entity;
using Lab2IPZ.req;

namespace Lab2IPZ;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class LoginPage : Window
{
    public LoginEntity LoginEntity { get; set; }
    private const string ServerAddress = "localhost"; // Адреса сервера
    private const int ServerPort = 5000; // Порт сервера
    public LoginPage()
    {
        InitializeComponent();
        LoginEntity = new LoginEntity("", "");
        DataContext = LoginEntity;
    }
    
    private async void LoginButton_Click(object sender, RoutedEventArgs e)
    {
        if (LoginEntity.name.Length == 0 || LoginEntity.password.Length == 0)
        {
            MessageBox.Show("Поля не можуть бути пусті!");    
        }else
        {
            try
            {
                LoginEntity registerEntity = new LoginEntity(LoginEntity.name, LoginEntity.password);

                var request_back = new
                {
                    command = "login_user",
                    username = registerEntity.name,
                    password = registerEntity.password,
                };
                
                var request = JsonSerializer.Serialize(request_back);
                var bytesToSend = Encoding.UTF8.GetBytes(request);

                using (var client = new TcpClient(ServerAddress, ServerPort))
                {
                    using (var stream = client.GetStream())
                    {
                        await stream.WriteAsync(bytesToSend, 0, bytesToSend.Length);

                        var buffer = new byte[1024];
                        int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                        string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        
                        var responseObject = JsonSerializer.Deserialize<ResponseWrapper>(response);
                        if (responseObject.success)
                        {
                            RegisterPage.userIdConst = int.Parse(responseObject.message);
                            var timeControlPage = new TimeControlPage();
                            timeControlPage.Show();
                            Close();
                        }
                        else
                        {
                            MessageBox.Show(responseObject.message);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                throw;
            }
        }
    }

    private void OpenRegisterWindow_Click(object sender, RoutedEventArgs e)
    {
        var register = new RegisterPage();
        register.Show();
        Close();
    }

    private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (DataContext is LoginEntity viewModel)
        {
            viewModel.password = PasswordBox.Password; 
        }
    }
    
    public class ResponseWrapper
    {
        public bool success { get; set; }
        public string message { get; set; }
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}