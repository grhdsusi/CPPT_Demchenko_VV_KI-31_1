﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Lab2IPZ.entity;
using Lab2IPZ.resp;

namespace Lab2IPZ;

public partial class NotificationPage : Window
{
    public ObservableCollection<NotificationEntity> NotificationEntity { get; set; } =
        new ObservableCollection<NotificationEntity>();
    public ICommand ViewMessageCommand { get; set; }
    public NotificationPage()
    {
        InitializeComponent();
        LoadNotifications();
        DataContext = this;
    }
    
    private async void LoadNotifications()
    {
        try
        {
           var notifications =  await new NotificationGetResponse().getNotifications();

            foreach (var notification in notifications)
            {
                NotificationEntity.Add(notification);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show($"Сталась помилка {e.Message}");
        }
    }
    
    private void Open_Time_Control_Page(object sender, RoutedEventArgs e)
    {
        var timeContolPage = new TimeControlPage();
        timeContolPage.Show();
        Close();
    }
    
    private void ViewMessage(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.CommandParameter is NotificationEntity notificationEntity)
        {
            var details = new NotificationDetails(notificationEntity);
            details.Show();
        }
    }

    private void Add_Notification_Page(object sender, RoutedEventArgs e)
    {
            var addNotificationPage = new AddNotificationPage();
            addNotificationPage.Show();
            Close();
    }
}