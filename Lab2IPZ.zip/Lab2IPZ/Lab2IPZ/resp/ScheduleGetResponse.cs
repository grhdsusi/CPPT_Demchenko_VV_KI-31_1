﻿using System.Collections.ObjectModel;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using Lab2IPZ.entity;

namespace Lab2IPZ.resp
{
    public class ScheduleGetResponse
    {
        private const string ServerAddress = "localhost"; 
        private const int ServerPort = 5000;

        public async Task<ObservableCollection<ScheduleEntity>> getSchedule()
        {
            var request_back = new
            {
                command = "get_schedules"
            };

            var request = JsonSerializer.Serialize(request_back);
            var bytesToSend = Encoding.UTF8.GetBytes(request);

            using (var client = new TcpClient(ServerAddress, ServerPort))
            {
                using (var stream = client.GetStream())
                {
                    await stream.WriteAsync(bytesToSend, 0, bytesToSend.Length);

                    var buffer = new List<byte>();
                    var tempBuffer = new byte[1024];
                    int bytesRead;

                    while ((bytesRead = await stream.ReadAsync(tempBuffer, 0, tempBuffer.Length)) > 0)
                    {
                        buffer.AddRange(tempBuffer.Take(bytesRead));
                        if (bytesRead < tempBuffer.Length)
                        {
                            break; 
                        }
                    }

                    string response = Encoding.UTF8.GetString(buffer.ToArray());
                    var scheduleList = JsonSerializer.Deserialize<List<ScheduleEntity>>(response);
      
                    return new ObservableCollection<ScheduleEntity>(scheduleList);
                    
                }
            }
        }
    }
}
