﻿using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Windows;

namespace Lab2IPZ.resp;

public class TimerInfoResponse
{
    public string StartTime { get; set; }
    private const string ServerAddress = "localhost"; 
    private const int ServerPort = 5000;

    public async Task<string> GetTimerInfo(string id)
    {
        var request_back = new
        {
            command = "get_curr_active_timer",
            userId = id
        };

        var request = JsonSerializer.Serialize(request_back);
        var bytesToSend = Encoding.UTF8.GetBytes(request);

        using (var client = new TcpClient(ServerAddress, ServerPort))
        {
            using (var stream = client.GetStream())
            {
                await stream.WriteAsync(bytesToSend, 0, bytesToSend.Length);

                var buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        
                var responseObject = JsonSerializer.Deserialize<ResponseWrapper>(response);
                if (responseObject.success)
                {
                    return responseObject.message;
                }

                return responseObject.message;
            }
        }
    }
    
    public class ResponseWrapper
    {
        public bool success { get; set; }
        public string message { get; set; }
    }
}