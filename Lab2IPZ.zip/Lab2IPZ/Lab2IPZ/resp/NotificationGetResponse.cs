﻿using System.Collections.ObjectModel;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using Lab2IPZ.entity;

namespace Lab2IPZ.resp;

public class NotificationGetResponse
{
    private const string ServerAddress = "localhost"; 
    private const int ServerPort = 5000;

    public async Task<ObservableCollection<NotificationEntity>> getNotifications()
    {
        var request_back = new
        {
            command = "get_notifications"
        };

        var request = JsonSerializer.Serialize(request_back);
        var bytesToSend = Encoding.UTF8.GetBytes(request);

        using (var client = new TcpClient(ServerAddress, ServerPort))
        {
            using (var stream = client.GetStream())
            {
                await stream.WriteAsync(bytesToSend, 0, bytesToSend.Length);

                var buffer = new List<byte>();
                var tempBuffer = new byte[1024];
                int bytesRead;

                while ((bytesRead = await stream.ReadAsync(tempBuffer, 0, tempBuffer.Length)) > 0)
                {
                    buffer.AddRange(tempBuffer.Take(bytesRead));
                    if (bytesRead < tempBuffer.Length)
                    {
                        break; 
                    }
                }

                string response = Encoding.UTF8.GetString(buffer.ToArray());
                
                var notificationList = JsonSerializer.Deserialize<List<NotificationEntity>>(response);
      
                return new ObservableCollection<NotificationEntity>(notificationList);
                    
            }
        }
    }
}
