﻿using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using Lab2IPZ.entity;
using Lab2IPZ.req;

namespace Lab2IPZ;

public partial class RegisterPage : Window
{
    public RegisterEntity RegisterEntity { get; set; }
    private const string ServerAddress = "localhost"; // Адреса сервера
    private const int ServerPort = 5000; // Порт сервера
    public static int userIdConst = -1; 
    public RegisterPage()
    {
        InitializeComponent();
        RegisterEntity = new RegisterEntity("",  "");
        DataContext = RegisterEntity;
    }
    
    private async void RegisterButton_Click(object sender, RoutedEventArgs e)
    {

        if (RegisterEntity.name.Length == 0 || RegisterEntity.password.Length == 0)
        {
            MessageBox.Show("Поля не можуть бути пусті!");    
        }else
        {
            try
            {
                RegisterRequest registerRequest = new RegisterRequest(RegisterEntity.name, RegisterEntity.password);
                var request_back = new
                {
                    command = "create_user",
                    username = registerRequest.name,
                    password = registerRequest.password,
                };
                
                var request = JsonSerializer.Serialize(request_back);
                var bytesToSend = Encoding.UTF8.GetBytes(request);

                using (var client = new TcpClient(ServerAddress, ServerPort))
                {
                    using (var stream = client.GetStream())
                    {
                        await stream.WriteAsync(bytesToSend, 0, bytesToSend.Length);

                        var buffer = new byte[1024];
                        int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                        string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        
                        var responseObject = JsonSerializer.Deserialize<ResponseWrapper>(response);
                        if (responseObject.success)
                        {
                            userIdConst = int.Parse(responseObject.message);
                            var timeControlPage = new TimeControlPage();
                            timeControlPage.Show();
                            Close();
                        }
                        else
                        {
                            MessageBox.Show(responseObject.message);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Сталася помилка {exception.Message}");
                throw;
            }
        }
    }
    
    private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (DataContext is RegisterEntity viewModel)
        {
            viewModel.password = PasswordBox.Password; 
        }
    }

    public class ResponseWrapper
    {
        public bool success { get; set; }
        public string message { get; set; }
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        this.Close();
    }

    private void BackToLogin_Click(object sender, RoutedEventArgs e)
    {
        var loginWindow = new LoginPage();
        loginWindow.Show();
        this.Close();
    }
}