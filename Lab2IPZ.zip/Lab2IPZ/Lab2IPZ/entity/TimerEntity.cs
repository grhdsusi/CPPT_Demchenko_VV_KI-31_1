﻿using System.ComponentModel;

namespace Lab2IPZ.entity
{
    public class TimerEntity : INotifyPropertyChanged
    {
        private string _startTime;
        private string _currentTime;

        public event PropertyChangedEventHandler PropertyChanged;

        public TimerEntity(string startTime)
        {
            StartTime = startTime;
        }

        public string StartTime
        {
            get => _startTime;
            set
            {
                _startTime = value;
                OnPropertyChanged(nameof(StartTime));
            }
        }

        public string CurrentTime
        {
            get => _currentTime;
            set
            {
                _currentTime = value;
                OnPropertyChanged(nameof(CurrentTime));
            }
        }

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
