﻿using System.ComponentModel;

namespace Lab2IPZ.entity
{
    public class RegisterEntity : INotifyPropertyChanged
    {
        private string _name;
        private string _password;
        

        public string name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged(nameof(name));
                }
            }
        }

        public string password
        {
            get => _password;
            set
            {
                if (_password != value)
                {
                    _password = value;
                    OnPropertyChanged(nameof(password));
                }
            }
        }
        
        public RegisterEntity(string name, string password)
        {
            this._name = name;
            this._password = password;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}