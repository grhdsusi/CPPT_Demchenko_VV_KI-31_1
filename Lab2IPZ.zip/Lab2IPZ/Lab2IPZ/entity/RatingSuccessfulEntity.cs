﻿namespace Lab2IPZ.entity;

public class RatingSuccessfulEntity
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string StartTime { get; set; }
    public string Duration { get; set; }
    public string EndTime { get; set; }
}