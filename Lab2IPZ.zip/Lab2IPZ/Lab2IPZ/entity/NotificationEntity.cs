﻿namespace Lab2IPZ.entity;

public class NotificationEntity
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string CreatedTimeStamp { get; set; } = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
}