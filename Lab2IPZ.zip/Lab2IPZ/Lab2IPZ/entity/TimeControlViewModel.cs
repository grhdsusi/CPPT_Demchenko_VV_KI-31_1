﻿using System;
using System.ComponentModel;
using System.Timers;
using System.Windows.Input;
using System.Windows.Threading;
using Lab2IPZ.req;
using Lab2IPZ.resp;
using Timer = System.Timers.Timer;

namespace Lab2IPZ
{
    public class TimeControlViewModel : INotifyPropertyChanged
    {
        private Timer _timer;
        private DateTime _startTime;
        private DateTime _currentTime;
        private bool _isRunning;
        private readonly TimerInfoResponse _timerInfoResponse;
        private readonly Dispatcher _dispatcher;

        public TimeControlViewModel()
        {
            _dispatcher = Dispatcher.CurrentDispatcher;
            StartCommand = new RelayCommand(StartTimer, CanStartTimer);
            StopCommand = new RelayCommand(StopTimer, CanStopTimer);

            _timerInfoResponse = new TimerInfoResponse();
            _timer = new Timer(1000);
            _timer.Elapsed += OnTimerTick;

            // Ініціалізація таймера при створенні вікна
            InitializeTimerAsync();
        }

        public ICommand StartCommand { get; }
        public ICommand StopCommand { get; }

        private bool CanStartTimer() => !_isRunning;
        private bool CanStopTimer() => _isRunning;

        private async void InitializeTimerAsync()
        {
            try
            {
                string userId = RegisterPage.userIdConst.ToString();
                string durationInfo = await _timerInfoResponse.GetTimerInfo(userId);

                _dispatcher.Invoke(() =>
                {
                    if (!string.IsNullOrEmpty(durationInfo) && TimeSpan.TryParse(durationInfo, out var duration))
                    {
                        // Якщо є активний таймер, запускаємо його
                        _startTime = DateTime.Now - duration;
                        CurrentTime = DateTime.Now;
                        _isRunning = true;
                        _timer.Start();
                    }
                    else
                    {
                        // Якщо немає активного таймера, встановлюємо початковий стан
                        _startTime = DateTime.Now;
                        CurrentTime = _startTime;
                        _isRunning = false;
                    }
                    
                    UpdateCommandStates();
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка при ініціалізації таймера: {ex.Message}");
                _dispatcher.Invoke(() =>
                {
                    _startTime = DateTime.Now;
                    CurrentTime = _startTime;
                    _isRunning = false;
                    UpdateCommandStates();
                });
            }
        }

        private void UpdateCommandStates()
        {
            ((RelayCommand)StartCommand).RaiseCanExecuteChanged();
            ((RelayCommand)StopCommand).RaiseCanExecuteChanged();
        }

        private void OnTimerTick(object sender, ElapsedEventArgs e)
        {
            _dispatcher.Invoke(() =>
            {
                CurrentTime = DateTime.Now;
            });
        }

        private async void StartTimer()
        {
            try
            {
                // Створюємо новий таймер
                _startTime = DateTime.Now;
                CurrentTime = DateTime.Now;
                _isRunning = true;
                _timer.Start();

                // Відправляємо запит на створення таймера на сервері
                await new TimeCreateRequest(
                    RegisterPage.userIdConst, 
                    _startTime.ToString("yyyy-MM-ddTHH:mm:ss")
                ).createTimer();

                UpdateCommandStates();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка при запуску таймера: {ex.Message}");
                // Повертаємо стан назад у разі помилки
                _isRunning = false;
                _timer.Stop();
                UpdateCommandStates();
            }
        }

        private async void StopTimer()
        {
            try
            {
                _isRunning = false;
                _timer.Stop();

                await new TimeUpdateRequest(
                    RegisterPage.userIdConst, 
                    DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss")
                ).closeTimer();

                UpdateCommandStates();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка при зупинці таймера: {ex.Message}");
                UpdateCommandStates();
            }
        }

        public DateTime CurrentTime
        {
            get => _currentTime;
            set
            {
                if (_currentTime != value)
                {
                    _currentTime = value;
                    OnPropertyChanged(nameof(CurrentTime));
                    OnPropertyChanged(nameof(ElapsedTime));
                }
            }
        }

        public string ElapsedTime => (_currentTime - _startTime).ToString(@"hh\:mm\:ss");

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}