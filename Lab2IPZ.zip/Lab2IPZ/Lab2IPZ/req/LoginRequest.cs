﻿namespace Lab2IPZ.req;

public class LoginRequest
{
    public string name { get; set; }
    public string password { get; set; }

    public LoginRequest(string name, string password)
    {
        this.name = name;
        this.password = password;
    }
}
