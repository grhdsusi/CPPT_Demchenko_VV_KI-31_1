﻿namespace Lab2IPZ.req;

public class RegisterRequest
{
    public string name { get; set; }
    public string password { get; set; }

    public RegisterRequest(string name, string password)
    {
        this.name = name;
        this.password = password;
    }
}