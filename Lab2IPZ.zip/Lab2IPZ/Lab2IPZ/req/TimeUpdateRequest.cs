﻿using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Windows;

namespace Lab2IPZ.req;

public class TimeUpdateRequest
{
    public int Id { get; set; }
    public string EndTime { get; set; }

    private const string ServerAddress = "localhost"; 
    private const int ServerPort = 5000;

    public TimeUpdateRequest(int id, string endTime)
    {
        Id = id;
        EndTime = endTime;
    }
    
    public async Task closeTimer()
    {
        var request_back = new
        {
            command = "update_timer",
            userId = Id.ToString(),
            endTime = EndTime,
        };

        var request = JsonSerializer.Serialize(request_back);
        var bytesToSend = Encoding.UTF8.GetBytes(request);

        using (var client = new TcpClient(ServerAddress, ServerPort))
        {
            using (var stream = client.GetStream())
            {
                await stream.WriteAsync(bytesToSend, 0, bytesToSend.Length);

                var buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        
                var responseObject = JsonSerializer.Deserialize<ResponseWrapper>(response);
                if (!responseObject.success){
                    MessageBox.Show(responseObject.message);
                }
            }
        }
    }
    
    public class ResponseWrapper
    {
        public bool success { get; set; }
        public string message { get; set; }
    }
}