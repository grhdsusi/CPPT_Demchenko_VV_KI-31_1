﻿using System.Collections.ObjectModel;
using System.Windows;
using Lab2IPZ.entity;
using Lab2IPZ.resp;

namespace Lab2IPZ;

public partial class SchedulePage : Window
{
    public ObservableCollection<ScheduleEntity> ScheduleEntity { get; set; } = new ObservableCollection<ScheduleEntity>();

    public SchedulePage()
    {
        InitializeComponent();
        LoadSchedule();
        DataContext = this;
    }

    private async void LoadSchedule()
    {
        try
        {
            var schedules = await new ScheduleGetResponse().getSchedule();

            foreach (var schedule in schedules)
            {
                Console.WriteLine(schedule.Username);
                Console.WriteLine(schedule.StartTime);
                Console.WriteLine(schedule.Duration);
                Console.WriteLine(schedule.EndTime);
                ScheduleEntity.Add(schedule);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show($"Сталась помилка {e.Message}");
        }
    }
    
    private void Open_Time_Control_Page(object sender, RoutedEventArgs e)
    {
        var timeContolPage = new TimeControlPage();
        timeContolPage.Show();
        Close();
    }
}